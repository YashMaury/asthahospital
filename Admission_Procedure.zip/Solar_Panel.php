<?php include "include/header.php";?>
            
            
<!-- BREADCRUMBS -->


<div class="bread-crumb-wrap ibc-wrap-2">
    <div class="container padding_remove">
        <div class="inner-page-title-wrap col-xs-12 col-md-12 col-sm-12">
            <div class="bread-heading">
                <h3>Solar Panel Plant</h3>
            </div>
            <div class="bread-crumb pull-right">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Solar_Panel.php">Solar Panel</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid managment_contents">
    <div class="container">
        <div class="row">
            <div class="bhoechie-tab-container departments">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="Intensive_Care_Unit.php" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>ICU</span>
                        </a>
                        <a href="NICU.php" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>NICU</span>
                        </a>
                        <a href="PICU.php" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>PICU</span>
                        </a>
                        <a href="Pathology.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Pathology</span>
                        </a>
                        <a href="Pharmacy.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Pharmacy</span>
                        </a>
                    
                        <a href="Patient_Rooms.php" class="list-group-item">
                            <h4 class="fa fa-eye fontawsme"></h4><span>Patient Rooms</span>
                        </a>
                       
                        <a href="Solar_Panel.php" class="list-group-item active">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Solar Panel Plant</span>
                        </a>
                        <a href="Power_BackUp_Plant.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Power Back Plant</span>
                        </a>
                        <a href="Operation_Unit.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Operation Theater Unit</span>
                        </a>
                    </div> 
                </div>

                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 bhoechie-tab">
                    <!-- train section -->
                    <div class="bhoechie-tab-content active">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <h4 style="font-size:18px; color:red; border-bottom: 2px solid black; padding-bottom: 5px;">Solar Panel !</h4> 
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="row" id="slider">
                                <div class="col-sm-12 col-md-12 col-lg-12"  id="carousel-bounding-box">
                                    <div class="carousel slide" id="myCarousel">
                                        <!-- Carousel items -->
                                        <div class="carousel-inner ach_slider" style="height:350px;">

                                            <div class="active item" data-slide-number="0">
                                                <img src="images/Services/Solar_Panel_Plant.jpg">
                                            </div>

                                         <div class="item" data-slide-number="1">
                                             <img src="images/Services/Solar_Panel_Plant1.jpg">
                                            </div>
                                           

                                        </div><!-- Carousel nav -->
                                        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                            <span class="glyphicon glyphicon-chevron-left"></span>                                       
                                        </a>
                                        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                            <span class="glyphicon glyphicon-chevron-right"></span>                                       
                                        </a>                                
                                    </div> 
                                </div>
                                    </div><hr>
                                    <p style="text-align: justify; font-size:13.5px;  line-height:25px;">
                                       Astha Hospital uses Solar Power Panel to heat the Water supplying in the different – different area of Hospital. Astha Hospital contributes the country
                                       in saving the Power Energy by installing the Solar Panel in their premises.
                                        Solar Panel refers to a panel designed to absorb the sun's rays as a source 
                                       of energy for generating electricity or heating.  

                                    </p>
                                    <p style="text-align: justify; font-size:13.5px;  line-height:25px;">
In Astha Hospital, a photovoltaic module is a packaged, connected assembly of typically 7×14 solar cells. 
Solar Photovoltaic panels constitute the solar array of a photovoltaic system that generates and supplies solar 
electricity in Astha Hospital. Each module is rated by its DC output power under standard test conditions, and 
typically ranges from 100 to 365 watts. The efficiency of a module determines the area of a module given the same 
rated output – an 8% efficient 230 watt module will have twice the area of a 16% efficient 230 watt module. 
A single solar module can produce only a limited amount of power; most installations contain multiple modules. 
Here in Astha Hospital, A photovoltaic system typically includes a panel or an array of solar modules, 
a solar inverter, and sometimes a battery and/or solar tracker and interconnection wiring.


                                        
                                        </p>
                                        <p style="text-align: justify; font-size:13.5px;  line-height:25px;">
                                       Hence, Solar power is the conversion of sunlight into electricity, either directly using photovoltaic (PV), 
                                        or indirectly using concentrated solar power (CSP). Concentrated solar power systems use lenses or mirrors
                                        and tracking systems to focus a large area of sunlight into a small beam. Photovoltaics convert light into an
                                        electric current using the photovoltaic effect.
                                        </p>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div> 
                </div>

            </div>
        </div>
    </div>
</div>



<?php

include 'include/footer.php';

?>