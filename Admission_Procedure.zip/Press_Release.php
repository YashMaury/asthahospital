<?php include "include/header.php";?>
            
             
<!-- BREADCRUMBS -->

<div class="bread-crumb-wrap ibc-wrap-2">
    <div class="container padding_remove">
        <div class="inner-page-title-wrap col-xs-12 col-md-12 col-sm-12">
            <div class="bread-heading">
                <h3>Press Release</h3>
            </div>
            <div class="bread-crumb pull-right">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Press_Release.php">Press Release</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid managment_contents">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12  padding_remove padding_btm">
                      <div class="bhoechie-tab-container departments">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bhoechie-tab-menu">
                   
                       
                            <div class="list-group">
                                <a href="Press_Release.php" class="list-group-item active">
                            <h4 class="fa fa-user fontawsme"></h4><span>Press Release</span>
                        </a>
                                <a href="Social_Media_Coverage.php" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>Social Media Coverage</span>
                        </a>
                                <a href="health_checkup_packages.php" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>Health Checkup Packages</span>
                        </a>
                                <a href="Gallery.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Gallery</span>
                        </a>
                                <!-- <a href="Health_Tips.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Health Tips</span>
                        </a>
                                <a href="Events_Free_Check_Ups.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Events and Free Check Ups</span>
                        </a>
                    
                                <a href="Testimonials.php" class="list-group-item">
                            <h4 class="fa fa-eye fontawsme"></h4><span>Testimonials</span>
                        </a> -->
<!--                                <a href="News_Letters.php" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>News Letters</span>
                        </a>-->
                       
                      
                      
                    </div> 
                       
                   
                </div>
                      </div>
                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 bhoechie-tab">
                    <div class="row gallery clearfix">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                           <h4 style="font-size:18px; color:red; border-bottom: 2px solid black; padding-bottom: 5px;">Press Release !</h4> 
                        </div>
                        <!-- <div class="col-sm-12 col-md-12 col-lg-12">
                            <img src="images/subh.jpg" style="width: 100%;" class="thumbnail"/>
                        </div> -->
                       <div class="col-sm-12 col-md-12 col-lg-12">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 sec3sub2">
                                    <div class="content-tabs">
                                      
                                 <!--       <ul class="nav nav-tabs">
                                                <li class="active"><a data-toggle="tab" class="" href="#tab-home">2018</a></li>
                                                 <li><a data-toggle="tab" class="" href="#tab-home">2017</a></li>
                                            <li><a data-toggle="tab" href="#tab-messages">2014</a></li>
                                            <li><a data-toggle="tab" href="#tab-settings">2013</a></li> 
                                        </ul> -->
                                      
                                        <!-- <div class="tab-content">
                                            <div id="tab-home" class="tab-pane tab_pane fade in active row">

                                                <div class="col-md-12">

                                                   <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    June<br>
                                                                    <span>
                                                                        22, 2018 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="#">
                                                                      Obstetric & Gynecology Surgeon Dr. Amrita Agrahari performed an Operation of Tumor
                                                                      </a>
                                                                </h5>
                                                                <p>
                                                                    Allahabad, June 22: A Big Tumor has been taken out from the Patient Ms. Bharti Sharma by Dr. Amrita Agrahari today. </p>
                                                                <a class="more_link" href="images/Operation_Dr_Amrita.jpg" target='_blank'>View Photo</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    Jan<br>
                                                                    <span>
                                                                        30, 2017 </span>
                                                                </div>
                                                                <h5>
                                                                   <a href='#'>
                                                                    Famous Pediatric Surgeon Dr. Dhanesh Agrahari performed Laproscopic Appendicectomy </a>
                                                                </h5>
                                                                <p style="text-align: justify;">
                                                                    Famous Pediatric Surgeon Dr. Dhanesh Agrahari  successfully performed Laproscopic Appendicectomy of a 5 Year Old NRI Child in Astha Hospital, Allahabad. You can see the Photo of the Post Operative of this Child. 
                                                                </p>
                                                               <a class="more_link" href="images/Operation%201.jpg" target="-blank">View Photo</a>
                                                            </div>
                                                        </div>
                                                    </div>
  <!--                                                   <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>-->
                                                </div>

                                            </div>
<!--                                            <div id="tab-profile" class="tab-pane tab_pane fade row"> 
                                                <div class="col-md-12">

                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                            <div id="tab-messages" class="tab-pane tab_pane fade row">
                                                <div class="col-md-12">

                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                            <div id="tab-settings" class="tab-pane tab_pane fade row">

                                                <div class="col-md-12">

                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="pressreleases_cont">
                                                        <div class="pressreleases_topbg">
                                                            <div class="pressreleases_cbg">
                                                                <div class="datetext_bg">
                                                                    April<br>
                                                                    <span>
                                                                        16 
                                                                    </span>
                                                                </div>
                                                                <h5>
                                                                    <a href="">
                                                                        Astha hospital has centrally air-conditioned OPD block facilitated with round the clock Pharmacy backup & a big waiting lobby with nice ambience & comfort. 
                                                                    </a>
                                                                </h5>
                                                                <p>
                                                                    Mumbai, April 16: The DreamChasers football talent hunt, which is being launched by Proforce, has received a shot in the arm, thanks to the Kokilaben Dhirubhai Ambani Hospital &amp; Medical Research Institute (KDAH&amp;MRI) joining hands to provide medical assistance to the young trainees during ...</p>
                                                                <a class="more_link" href="">more</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>-->
                                        </div>
                                    </div>
                                </div>
                            </div>   
                        </div>
<br>
<br>



                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 


<?php
 include 'include/footer.php';
 
 
 ?>