<?php include "include/header.php";?>
            
<!-- BREADCRUMBS -->


<div class="bread-crumb-wrap ibc-wrap-2">
    <div class="container padding_remove">
        <div class="inner-page-title-wrap col-xs-12 col-md-12 col-sm-12">
            <div class="bread-heading">
                <h3>ICU</h3>
            </div>
            <div class="bread-crumb pull-right">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="Pharmacy.php">Pharmacy</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid managment_contents">
    <div class="container">
        <div class="row">
            <div class="bhoechie-tab-container departments">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 bhoechie-tab-menu">
                    <div class="list-group">
                        <a href="Intensive_Care_Unit.php" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>ICU</span>
                        </a>
                        <a href="NICU.php" class="list-group-item">
                            <h4 class="fa fa-user fontawsme"></h4><span>NICU</span>
                        </a>
                        <a href="PICU.php" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>PICU</span>
                        </a>
                        <a href="Hygiene.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Hygiene</span>
                        </a>
                        <a href="Pathology.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Pathology</span>
                        </a>
                        <a href="Pharmacy.php" class="list-group-item active">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Pharmacy</span>
                        </a>
                    
                        <a href="Patient_Rooms.php" class="list-group-item">
                            <h4 class="fa fa-eye fontawsme"></h4><span>Patient Rooms</span>
                        </a>
                        <a href="Oxygen_Plant.php" class="list-group-item">
                            <h4 class="fa fa-h-square fontawsme"></h4><span>Oxygen Plant</span>
                        </a>
                       
                        <a href="Solar_Panel.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Solar Panel Plant</span>
                        </a>
                        <a href="Power_BackUp_Plant.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Power Back Plant</span>
                        </a>
                        <a href="Water_Treatment.php" class="list-group-item">
                            <h4 class="fa fa-shield fontawsme"></h4><span>Water Treatment Plant</span>
                        </a>
                        <a href="Operation_Unit.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>Operation Theater Unit</span>
                        </a>
                        <a href="Dialysis_Unit.php" class="list-group-item">
                            <h4 class="fa fa-plus-square fontawsme"></h4><span>High End Dialysis Unit</span>
                        </a>
                    </div> 
                </div>

                <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 bhoechie-tab">
                    <!-- train section -->
                    <div class="bhoechie-tab-content active">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <h4 style="font-size:18px; color:red; border-bottom: 2px solid black; padding-bottom: 5px;">Pharmacy Section !</h4> 
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">
                                    <div class="row" id="slider">
                                <div class="col-sm-12 col-md-12 col-lg-12"  id="carousel-bounding-box">
                                    <div class="carousel slide" id="myCarousel">
                                        <img src="images/Gallery/Pharmacy.jpg" style="width:800px; height:400px;">
                                                                       
                                    </div> 
                                </div>
                                    </div><hr>
                                    <p style="text-align: justify; font-size:13.5px;  line-height:25px;">
                                        Astha Hospital has a round the clock <span style="border-bottom: 2px solid red;"> Pharmacy </span> Back Up with a never ending Medicine in their Section. We have a larger range of Medication Stock, including some more specialized and investigational medications. We usually give medication to the Hospital Patients and the OPD Patients and or prescribed by the Hospital Doctors.
                                    </p>
                                    
                                    <p style="text-align: justify; font-size:13.5px;  line-height:25px;">
                                     Astha Hospital Pharmacy provides a huge quantity of Medications daily which is allocated to the wards and to the ICU according to the prescription or the schedule. We are dedicated in terms of 
                                     <br><br>
                                     • Providing an adequate supply of medication to each our Medical Departments.<br>
                                     • Assuring a Quality Medication for the betterment of the Patient.<br>
                                     • Monitoring, Evaluation and Assurance of the Quality of the Drugs.<br>
                                     • Providing the upto date Medicines to the OPD Patients and keeping an eye on the Expired Medicines.

                                        
                                        </p>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div> 
                </div>

            </div>
        </div>
    </div>
</div>



<?php

include 'include/footer.php';

?>